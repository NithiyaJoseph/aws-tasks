
from urllib import response
import boto3
import json
import sys
from datetime import datetime
import time

from pip import main

class Patchjob(object):
     def __init__(self,region):
         self.ssm = boto3.client('ssm',region_name=region)
         self.ec2=boto3.client('ec2',region_name=region)
         self.filename = ".\\patch.json"
         with open(self.filename) as json_file:
            data = json.load(json_file)
            self.patch = data['patch']
            self.ApplyAllPatches = data['ApplyAllPatches']
            self.deploy_from = data['deploy_from']

     def getInstances(self):
        try:
            response = self.ec2.describe_instances()
            print("==== Instances List: %s ====" % response)
            return response
        except Exception as e:
            raise Exception('An exception occurred: %s' % e)
     def InstancesId(self):
            Ids=self.getInstances()
            for instance in Ids['Reservations']:
                instanceid=instance['Instances'][0]['InstanceId']
                if(self.ApplyAllPatches):
                    for patch in self.patch:
                            command = "%s" % (self.patch[patch][0])
                            print("==== Running the patch for patch number %s ====" % patch)
                            print (instance['Instances'][0]['InstanceId'], command)
                            if instance['Instances'][0]['State']['Name'] == 'running':
                                ssm_response = self.sendSSM(instance['Instances'][0]['InstanceId'], command, 'Patching')
                                if (not ssm_response):

                                    sys.exit(1)
                            else:
                                print("Instance {} state is not running.".format(instance['Instances'][0]['InstanceId']))
                else:
                     for patch in self.patch:
                            if(patch >= self.deploy_from):
                                command = "%s" % (self.patch[patch][0])
                                print("==== Running the patch for patch number %s ====" % patch)
                                if instance['Instances'][0]['State']['Name'] == 'running':
                                    ssm_response = self.sendSSM(instance['Instances'][0]['InstanceId'], command, 'Patching')
                                    if (not ssm_response):
                                        sys.exit(1)
                                else:
                                    print("Instance {} state is not running.".format(instance['Instances'][0]['InstanceId']))
     
     def sendSSM(self, instanceId, command, stage):

        print("==== Running SSM Commands ====")
        print (instanceId, command)
        try:
            response = self.ssm.send_command(
                InstanceIds=[instanceId],
                DocumentName="AWS-RunShellScript",
                Comment="Patch",
                Parameters={
                    'commands': [command]
                })
            time.sleep(5)
            status = True
            return_status = True
            while (status):
                response1 = self.ssm.list_command_invocations(CommandId=response['Command']['CommandId'])
                s = response1['CommandInvocations'][0]['Status']
                #print("==== SSM Command Status: %s ====" % s)
                if ((s != 'Success') and (s != 'Failed') and (s != 'Cancelled') and (s != 'TimedOut')):

                    status = True
                elif ((s == 'Failed') or (s == 'Cancelled') or (s == 'TimedOut')):
                    print("==== %s stage on instance with id %s failed, hence exiting the system ====" % (stage, instanceId))
                    return_status = False
                    break
                elif (s == 'Success'):
                    print("==== %s stage on instance with id %s sucess, hence exiting the system ====" % (stage, instanceId))
                    status = False
                time.sleep(2)
            return return_status
        except Exception as e:
            raise Exception('An exception occurred: %s' % e)

region='us-east-1'
respo=Patchjob(region)
respo.InstancesId()
              


         